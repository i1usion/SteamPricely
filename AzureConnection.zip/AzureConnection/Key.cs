using System;

namespace Company.Function
{
    public class Key{
    public string PrivKey { get; set; }
    public string CreatedAt { get; set; }
    public string UpdatedAt { get; set; }
    public string EndAt { get; set; }
    }
    
}