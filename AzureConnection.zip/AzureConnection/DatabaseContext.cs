using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Company.Function
{
     public class DatabaseContext
    {
        private readonly string connectionString;
        

        public DatabaseContext(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public IEnumerable<Skin> GetSkins()
        {
            var skins = new List<Skin>();
            string Query = "Select * from SkinsPrices";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(Query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    skins.Add(new Skin
                    {
                        Name = reader["Name"].ToString(),
                        Exterior = reader["Exterior"].ToString(),
                        ImageUrl = reader["ImageUrl"].ToString(),
                    });
                }   
                reader.Close();
            }
            return skins;
        }

        public Boolean GetKey(string checkKey)
        {
            
            var keys = new Key();
            keys.PrivKey = "";
            string Query = $"Select * from PremiumKey where PrivKey = '{checkKey}'";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(Query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                
                while (reader.Read())
                {
                    keys.PrivKey = reader["PrivKey"].ToString();
                    keys.EndAt = reader["EndAt"].ToString();

                }   
                reader.Close();
            }
            if(keys.PrivKey != "" && Convert.ToDateTime(keys.EndAt) > DateTime.Now){
                return true;
            }
            else{
                return false;
            }
        }


    }
}