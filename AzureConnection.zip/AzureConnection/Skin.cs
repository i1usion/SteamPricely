namespace Company.Function
{
    public class Skin{
    public string Name { get; set; }
    public string Exterior { get; set; }
    public string ImageUrl { get; set; }
    }
    
}